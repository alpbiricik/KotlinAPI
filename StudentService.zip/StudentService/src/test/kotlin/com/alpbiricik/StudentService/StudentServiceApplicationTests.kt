package com.alpbiricik.StudentService

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class StudentServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
