package com.alpbiricik.StudentService.controller

import com.alpbiricik.StudentService.entity.Student
import com.alpbiricik.StudentService.service.StudentService
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/students")
class StudentController(
    private val studentService: StudentService
) {

    @GetMapping
    fun getAllStudents(): List<Student> {
        return studentService.getAllStudents()
    }

    @GetMapping("/{id}")
    fun getStudentById(@PathVariable id: Long): ResponseEntity<Student> {
        val student = studentService.getStudentById(id)
        return if (student != null) {
            ResponseEntity.ok(student)
        } else {
            ResponseEntity.notFound().build()
        }
    }

    @PostMapping
    fun createStudent(@RequestBody student: Student): Student {
        return studentService.saveStudent(student)
    }

    @PutMapping("/{id}")
    fun updateStudent(@PathVariable id: Long, @RequestBody student: Student): ResponseEntity<Student> {
        val existingStudent = studentService.getStudentById(id)
        return if (existingStudent != null) {
            val updatedStudent = existingStudent.copy(
                name = student.name,
                email = student.email,
                age = student.age
            )
            ResponseEntity.ok(studentService.saveStudent(updatedStudent))
        } else {
            ResponseEntity.notFound().build()
        }
    }

    @DeleteMapping("/{id}")
    fun deleteStudent(@PathVariable id: Long): ResponseEntity<Void> {
        return if (studentService.getStudentById(id) != null) {
            val tempStudent = getStudentById(id)
            studentService.deleteStudent(id)
            ResponseEntity.noContent().build()
        } else {
            ResponseEntity.notFound().build()
        }

    }
}
