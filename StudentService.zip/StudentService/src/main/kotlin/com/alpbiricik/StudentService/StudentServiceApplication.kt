package com.alpbiricik.StudentService


import com.alpbiricik.StudentService.entity.Student
import com.alpbiricik.StudentService.service.StudentService
import org.springframework.boot.CommandLineRunner
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean


@SpringBootApplication
class StudentServiceApplication {

	@Bean
	fun init(studentService: StudentService) = CommandLineRunner {
		// Varsayılan öğrenci verilerini ekleme
		val student1 = Student(name = "John Doe", email = "john.doe@example.com", age = 20)
		val student2 = Student(name = "Jane Smith", email = "jane.smith@example.com", age = 22)

		studentService.saveStudent(student1)
		studentService.saveStudent(student2)
	}
}

fun main(args: Array<String>) {
	runApplication<StudentServiceApplication>(*args)
}
