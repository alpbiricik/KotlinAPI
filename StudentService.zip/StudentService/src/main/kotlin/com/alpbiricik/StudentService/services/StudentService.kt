package com.alpbiricik.StudentService.service

import com.alpbiricik.StudentService.entity.Student
import com.alpbiricik.StudentService.repository.StudentRepository
import org.springframework.stereotype.Service

@Service

class StudentService(
    private val studentRepository: StudentRepository

) {

    fun getAllStudents(): List<Student> {
        return studentRepository.findAll()
    }

    fun getStudentById(id: Long): Student {
        return studentRepository.findById(id).orElse(null)
    }

    fun saveStudent(student: Student): Student {
        return studentRepository.save(student)
    }

    fun deleteStudent(id: Long){
        studentRepository.deleteById(id)
    }
}
